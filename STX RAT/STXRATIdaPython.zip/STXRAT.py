"""
Author: YungBinary
Description: Helper script for analyzing STX RAT - sets comments
             for decrypted strings, resolved APIs, etc.
             Script is not perfect! There may be bugs.
Pre-reqs: Needs exports_map.json
"""

import yara
import pefile
import argparse
import struct
import idc
import json
import idaapi
import ida_ua
import ida_bytes
import idautils
import ida_idp
import hashlib
import sys
from Crypto.Cipher import AES


RULE_SOURCE = """rule XorBlock
{
    meta:
        author = "Yung Binary"
    strings:
        $decode_1 = {
            (04 ?? | 40 02 c6 | 41 ?? ??)    // add al, ?? or add al, sil or inc
            41 (30 | 31) 0? // xor [r8|r9], al
            ?? ?? ??
            (41 83 F? | 83 )// cmp r8d, ?? | cmp ??, ??
        }
    condition:
        any of them
}"""

RULE_SOURCE_2 = """rule ApiResolver
{
    meta:
        author = "Yung Binary"
    strings:
        $index_into_list = {
            48 8D 2C 40 // lea rbp, [rax+rcx*2]
            48 c1 e5 04 // shl rbp, 4
            48 8d 05 // lea rax, <32 bit displacement to pExportSha1AndSalts>
        }
    condition:
        any of them
}"""


def get_dll_exports(dll_file_path):
    """
    Get a list of export names given a DLL
    """

    exports = []

    pe = pefile.PE(dll_file_path)

    for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
        if not exp.name:
            continue
        name = exp.name.decode()
        exports.append(name)
    
    return exports

# Store the loaded binary's path
LOADED_BIN_PATH = idc.get_input_file_path()

# Load map of dlls and associated exports for later use
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
EXPORTS_MAP = None
with open(os.path.join(SCRIPT_DIR, "exports_map.json"), "r") as f:
    EXPORTS_MAP = json.load(f)


def infer_idx_from_call_site(ea):
    initial_mnem = idc.print_insn_mnem(ea)
    if initial_mnem != 'call':
        return None
    cur = idc.prev_head(ea)
    target_reg = None
    while cur != idaapi.BADADDR:

        #print(f"[+] Looking at {cur:#x}: {idc.GetDisasm(cur)}")
        op0 = idc.print_operand(cur, 0)
        if op0 not in ("ecx", target_reg):
            cur = idc.prev_head(cur)
            continue

        mnem = idc.print_insn_mnem(cur)
        op1 = idc.print_operand(cur, 1)
        t1 = idc.get_operand_type(cur, 1)
        # mov ecx, <reg>
        if not target_reg:
            if mnem == "mov" and t1 == idc.o_reg:
                target_reg = op1
                #print(f"Found target register: {target_reg}")
                cur = idc.prev_head(ea)
                continue
            elif mnem == "mov" and t1 == idc.o_imm:
                return idc.get_operand_value(cur, 1)
            elif mnem == "lea" and t1 == idc.o_displ:
                return idc.get_operand_value(cur, 1) & 0xFF
        
        # Target register to retrieve the value for
        else:
            #print(f"Checking if {op0} == {target_reg}")
            if mnem == "lea" and op0 == target_reg:
                #print(f"Found variant 1 match: {hex(idc.get_operand_value(cur, 1) & 0xFF)}")
                return idc.get_operand_value(cur, 1) & 0xFF
            elif mnem == "mov" and op0 == target_reg and t1 == idc.o_imm:
                #print(f"Found variant 2 match: {hex(idc.get_operand_value(cur, 1))}")
                return idc.get_operand_value(cur, 1)

        cur = idc.prev_head(cur)


def infer_offset_from_call_site(ea):
    initial_mnem = idc.print_insn_mnem(ea)
    if initial_mnem != 'call':
        print(f"ea at {hex(ea)} did not contain a call instruction")
        return None

    cur = idc.prev_head(ea)
    while cur != idaapi.BADADDR:
        insn = idaapi.insn_t()
        if not idaapi.decode_insn(insn, cur):
            print("Failed to decode instruction at infer_offset_from_call_site.")
            return None

        if (idc.print_insn_mnem(cur) == 'mov' and 
        insn.ops[0].type == idaapi.o_reg and
        insn.ops[1].type == idaapi.o_imm and
        idc.print_operand(cur, 0) == 'ecx'):
            return str(idc.get_operand_value(cur, 1))

        cur = idc.prev_head(cur)

    return None


def get_root_register(reg_name):
    """
    Convert some register, e.g. ax to associated 64 bit equivalent
    """
    ri = ida_idp.reg_info_t()
    ida_idp.parse_reg_name(ri, reg_name)
    reg_id = ri.reg

    if reg_id == -1:
        return None

    return ida_idp.get_reg_name(reg_id, 8)


def find_aes_encrypted_strings_and_routine():
    PATTERN = (
        "41 B8 04 00 00 00 "     # mov r8d, 4
        "48 03 1D ?? ?? ?? ?? "  # add rbx, cs:addressOfAesEncryptedStringsTable
        "48 8D 4D 10 "           # lea rcx, [rbp+10h]
        "48 8D 53 15"            # lea rdx, [rbx+15h]
    )

    ea = idaapi.find_binary(idc.get_inf_attr(idc.INF_MIN_EA), idc.get_inf_attr(idc.INF_MAX_EA), PATTERN, 16, idc.SEARCH_DOWN)
    if ea == idc.BADADDR:
        print("Could not find AES-encrypted strings table")
        return None, None

    print(f"Found AES-encrypted strings table usage at: {hex(ea)}")

    add_insn_ea = ea + 6
    insn = idaapi.insn_t()
    if not idaapi.decode_insn(insn, add_insn_ea):
        print("Failed to decode instruction at add_insn_ea.")
        return None, None
    
    op = insn.ops[1]
    if op.type == idaapi.o_mem:
        encrypted_strings_ea = idc.get_qword(op.addr)
        print(f"AES-encrypted strings table at: {hex(encrypted_strings_ea)}")
    else:
        print(f"Unexpected operand type: {op.type}")
        return None, None

    function_ea = idc.get_func_attr(ea, idc.FUNCATTR_START)

    return encrypted_strings_ea, function_ea


def parse_aes_table(data: bytes):
    results = {}
    offset = 0

    while offset < len(data):
        start_offset = offset

        key   = data[offset:offset+16]  # 16 bytes
        offset  += 16

        nonce  = data[offset:offset+5]   # 5 bytes
        offset  += 5

        ciphertext_len, = struct.unpack(">I", data[offset:offset+4]) # DWORD (4 bytes)
        offset  += 4

        ciphertext      = data[offset:offset+ciphertext_len]
        offset  += ciphertext_len

        cipher = AES.new(key, AES.MODE_CTR, nonce=nonce, initial_value=0)
        plaintext = cipher.decrypt(ciphertext)

        results[str(start_offset)] = {
            "key":  key,
            "nonce": nonce,
            "ciphertext_len": ciphertext_len,
            "ciphertext": ciphertext,
            "plaintext": plaintext
        }

    return results


def find_ciphertext_address(ea, dest_reg_name):
    """
    STX RAT stores ciphertext on the stack and makes use of the dest_reg_name register
    to serve as a pointer to the beginning of the ciphertext. It uses a rolling XOR loop
    to iterate over the ciphertext on the stack, overwriting each byte with the plaintext.
    """
    cur = idc.prev_head(ea)
    

    operand = None
    
    """
    Iterate from a given address backwards to find a Load Effective Address (lea) and store the source operand for use later
    """
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break

        for op in insn.ops:
            if (op.type == idc.o_reg and
                insn.get_canon_mnem() == 'lea' and
                idaapi.get_reg_name(insn.ops[0].reg, 8) == dest_reg_name):
                operand = idc.print_operand(cur, 1)
                break

        if operand:
            break

        cur = idc.prev_head(cur)

    if not operand:
        print(f"Failed to identify operand for {ea:#x}")
        return None

    """
    Using the found operand (as a string, e.g. rbp+var_x), iterate from the same address
    backwards until finding where it is set, e.g. a mov instruction. Identify the target register,
    which may be xmm0, eax, etc. Once we identify the target register, continue iterating backwards
    until we identify an address stored in that register. This address is the virtual address to the
    ciphertext.
    """

    # Set a limit for max iterations as a fail-safe when iterating instructions
    max_iter = 70
    cur_iter = 0
    cur = idc.prev_head(ea)
    target_reg = ''
    target_addr = 0x0
    while cur != idaapi.BADADDR:
        cur_iter += 1
        if cur_iter > max_iter:
            print("Max iteration reached.")
            break

        # Decode the instruction
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            print("Failed decoding instruction.")
            break

        #print(f"[+] Looking at {cur:#x}: {idc.GetDisasm(cur)}")

        if not target_reg:
            # The target register is the first operand
            #print(f"DEBUG: Checking if '{operand}' is in '{idc.print_operand(cur, 0)}'")
            if (operand in idc.print_operand(cur, 0)):
                # The target register is the second operand
                target_reg = get_root_register(idc.print_operand(cur, 1))
                #print(f"Found match at {cur:#x}: {idc.GetDisasm(cur)}, {operand} is in {idc.print_operand(cur, 0)}, target register: {target_reg}")
                cur = idc.prev_head(cur)
                continue

        else:
            #print(f"{get_root_register(idc.print_operand(cur, 0))} == {target_reg}")
            if (idc.print_insn_mnem(cur).startswith("mov") and (get_root_register(idc.print_operand(cur, 0)) == target_reg)):
                #print(f"Found the target address at: {cur:#x}: {idc.GetDisasm(cur)} => ")
                target_addr = insn.ops[1].addr
                break

        cur = idc.prev_head(cur)

    if target_addr:
        return target_addr

    return None


def find_starting_key(ea):
    """
    Identify the starting key
    """
    insn = ida_ua.insn_t()
    ida_ua.decode_insn(insn, ea)
    op = insn.ops[1]
    if (op.type == idaapi.o_imm):
        return op.value
    elif (op.type == idaapi.o_reg and insn.get_canon_mnem() == 'add'):
        # Get the operand register name and walk backwards
        # until we find where it's set with an immediate
        # if it isn't set with an immediate, just use the imul operand
        target_reg = idc.print_operand(ea, 1)

        cur = idc.prev_head(ea)

        while cur != idaapi.BADADDR:
            iinsn = ida_ua.insn_t()
            if ida_ua.decode_insn(iinsn, cur) == 0:
                break
            
            if (iinsn.ops[0].type == idaapi.o_reg and idc.print_operand(cur, 0) in ['cl']):
                cur = idc.prev_head(cur)
                iinsn = ida_ua.insn_t()
                ida_ua.decode_insn(iinsn, cur)
                return idc.get_operand_value(cur, 2)

            if not (iinsn.get_canon_mnem().startswith('mov')):
                cur = idc.prev_head(cur)
                continue

            if (idc.print_operand(cur, 0) == target_reg and iinsn.ops[1].type == idaapi.o_imm):
                return idc.get_operand_value(cur, 1)

            if (iinsn.ops[0].type != idaapi.o_reg) or idc.print_operand(cur, 0) not in ['rsi', 'esi', 'sil']:
                cur = idc.prev_head(cur)
                continue

            if (iinsn.ops[1].type == idaapi.o_imm):
                return idc.get_operand_value(cur, 1)

            cur = idc.prev_head(cur)
    else:
        cur = idc.prev_head(ea)
        while cur != idaapi.BADADDR:
            iinsn = ida_ua.insn_t()
            if ida_ua.decode_insn(iinsn, cur) == 0:
                break
            if (iinsn.get_canon_mnem() == 'imul' and iinsn.ops[2].type == idaapi.o_imm):
                return idc.get_operand_value(cur, 2)
            cur = idc.prev_head(cur)


def find_modulus(ea):
    """
    Walk backwards to identify the modulus used in resetting back to the start XOR key
    """

    cur = idc.prev_head(ea)

    
    """
    Iterate from a given address backwards to find a imul instruction and extract the 3rd (index 2) operand value
    """
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break

        if (insn.get_canon_mnem() == 'imul'):
            return idc.get_operand_value(cur, 2)

        cur = idc.prev_head(cur)

    return None


def find_ciphertext_length_counter(ea):
    """
    Walk forwards to identify the length of the ciphertext (including null terminator), and the register used as a counter
        cmp ebx, 27h
        jl
    """
    cur = idc.next_head(ea)
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break

        if (insn.get_canon_mnem() == 'cmp'):
            iinsn = ida_ua.insn_t()
            next_ea = idc.next_head(cur)
            if ida_ua.decode_insn(iinsn, next_ea) == 0:
                break
            if (iinsn.get_canon_mnem() == 'jl'):
                return idc.get_operand_value(cur, 1), idc.print_operand(cur, 0)

        cur = idc.next_head(cur)


def find_destination_register(ea):
    """
    Walk forwards to identify the destination register, e.g. r9
    """
    cur = idc.next_head(ea)
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break
        if (insn.get_canon_mnem() == 'xor'):
            return idc.print_operand(cur, 0)

        cur = idc.next_head(cur)

def find_api_resolver_wrapper(ea):
    """
    Find the wrapper of the API resolver function
    """

    for xref in idautils.XrefsTo(ea, flags=0):
        # Walk backwards and see if the immediate instructions are a prologue
        cur = idc.prev_head(xref.frm)
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            continue

        if (insn.get_canon_mnem() == 'sub' and idc.print_operand(cur, 0) == 'rsp'):
            return idc.get_func_attr(xref.frm, idc.FUNCATTR_START)


def find_exports_and_modules_addresses(ea):
    """
    Walk forwards to identify the pointer of the export/module sha1/salt arrays
    """

    exports_address = None
    modules_address = None

    cur = idc.next_head(ea)
    breaklimit = 10
    current = 0
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break
        if not exports_address and (insn.get_canon_mnem() == 'lea' and insn.ops[1].type == idaapi.o_mem):
            exports_address = insn.ops[1].addr
            cur = idc.next_head(cur)
            continue
        if (exports_address) and (insn.get_canon_mnem() == 'lea' and insn.ops[1].type == idaapi.o_mem):
            modules_address = insn.ops[1].addr
            break

        cur = idc.next_head(cur)
    
    return exports_address, modules_address

def resolve_api_set_comment(ea, exports_array_address, modules_array_address):
    idx = infer_idx_from_call_site(ea)
    if not idx:
        print(f'Failed to resolve index at call-site: {hex(ea)}')
        return None

    # Use the index to retrieve the associated module_idx/sha1/salt structure
    export_structure = ida_bytes.get_bytes(exports_array_address + (48 * idx), 48)
    module_index = struct.unpack('<I', export_structure[:4])[0]
    export_sha1 = export_structure[4:24]
    export_salt = export_structure[24:34]

    # Use the module index to retrieve the associated module name
    module_structure = ida_bytes.get_bytes(modules_array_address + (48 * module_index), 48)
    module_sha1 = module_structure[0:20]
    module_salt = module_structure[20:30]

    resolved_module_name = None
    global EXPORTS_MAP
    for module_name in EXPORTS_MAP:
        module_name_hash = hashlib.sha1(module_name.lower().encode() + module_salt).digest()
        if module_name_hash == module_sha1:
            resolved_module_name = module_name
            #print(f"{module_sha1.hex()}:{module_salt.hex()}: {module_name}")

    if not resolved_module_name and sys.platform == "win32":
        print(f"Could not resolve module name matching SHA-1: {module_sha1.hex()} at {hex(ea)}, using fallback option...")
        # Fallback try to search through the system directory and resolve the module
        dlls = [f.lower() for f in os.listdir("C:\\Windows\\System32") if f.endswith(".dll")]
        for dll_name in dlls:
            hashed_name = hashlib.sha1(dll_name.encode() + module_salt).digest()
            if hashed_name == module_sha1:
                resolved_module_name = dll_name
                #print(f"Found module via fallback, hash {module_sha1.hex()}: {dll_name}")
                EXPORTS_MAP[dll_name] = get_dll_exports(os.path.join(f"C:\\Windows\\System32\\", dll_name))

        if not resolved_module_name:
            print(f"[Fallback] could not resolve module name matching SHA-1: {module_sha1.hex()} at {hex(ea)}")
            return None
    elif not resolved_module_name:
        print(f"Could not resolve module name matching SHA-1: {module_sha1.hex()} at {hex(ea)}, fallback option is not available.")
        return None

    # We found the module, now find the export name associated with the export hash

    # Get the exports for the module
    resolved_export_name = None
    module_exports = EXPORTS_MAP[resolved_module_name]
    for module_export in module_exports:
        export_name_hash = hashlib.sha1(module_export.encode() + export_salt).digest()
        if export_name_hash == export_sha1:
            resolved_export_name = module_export

    if not resolved_export_name:
        #print(f"Failed to resolve export name matching SHA-1: {export_sha1.hex()} at {hex(ea)}")
        return None
    
    print(f"Resolved export '{resolved_export_name}' at: {hex(ea)}")
    idc.set_cmt(ea, f"{resolved_module_name}!{resolved_export_name}", 0)


def rolling_xor_decrypt(data: bytes, start: int, mod: int) -> bytes:
    """
    Rolling XOR decryption

    args:
        data: ciphertext to decode
        start: starting XOR key
        mod: modulus applied to the current iteration number (reset back to starting key)
    """
    keys = (start + (i % mod) for i in range(len(data)))
    return ''.join(chr(b ^ k) for b, k in zip(data, keys))


def yara_scan(raw_data: bytes, rule_source: str):
    yara_rules = yara.compile(source=rule_source)
    matches = yara_rules.match(data=raw_data)

    for match in matches:
        for block in match.strings:
            for instance in block.instances:
                yield instance.offset


def main():

    with open(LOADED_BIN_PATH, "rb") as f:
        data = f.read()


    pe = pefile.PE(data=data, fast_load=False)
    image_base = idaapi.get_imagebase()

    # Phase one: decode rolling XOR strings
    for xor_block_offset in yara_scan(data, RULE_SOURCE):
        # Convert the yara match offset to VA
        xor_block_ea = idaapi.get_fileregion_ea(xor_block_offset)
        #print(f"Found XOR decode basic block at address: {hex(xor_block_ea)}")

        # Get the starting XOR key from the add instruction:
        # add al, 0x39 or add al, sil
        start = find_starting_key(xor_block_ea)
        if not start:
            print(f"Failed to find starting key from XOR block: {hex(xor_block_ea)}")
            continue

        # Walk backwards to identify the modulus used in resetting back to the start XOR key
        # imul ecx, eax, 0x3A
        mod = find_modulus(xor_block_ea)
        if not mod:
            print(f"Failed to find modulus from XOR block: {hex(xor_block_ea)}")
            continue

        #print(f"Found modulus: {hex(mod)}")

        # Walk forwards to identify the length of the ciphertext:
        # cmp counter_register, 27h
        ciphertext_len, counter_register = find_ciphertext_length_counter(xor_block_ea)
        if not ciphertext_len:
            print(f"Failed to find ciphertext length from XOR block: {hex(xor_block_ea)}")
            continue
        if not counter_register:
            print(f"Failed to find counter register from XOR block: {hex(xor_block_ea)}")
            continue
        
        #print(f"Found counter register: {counter_register}")
        #print(f"Found ciphertext length: {hex(ciphertext_len)}")

        # Walk forwards to identify the destination register, e.g. r9, r8
        # xor [??], al
        dest_reg_name = find_destination_register(xor_block_ea)[1:-1]
        if not dest_reg_name:
            print(f"Failed to find destination register from XOR block: {hex(xor_block_ea)}")
            continue
        #print(f"Found destination register: {dest_reg_name}")

        # Walk backwards to identify the address of the ciphertext
        ciphertext_addr = find_ciphertext_address(xor_block_ea, dest_reg_name)
        if not ciphertext_addr:
            print(f"Failed to find ciphertext address from address: {hex(xor_block_ea)}")
            continue

        #print(f"Found ciphertext address: {hex(ciphertext_addr)}, length: {hex(ciphertext_len)}")
        ciphertext = ida_bytes.get_bytes(ciphertext_addr, ciphertext_len - 1)
        #print(f"Ciphertext hex: {ciphertext.hex()}")
        try:
            decrypted_str = repr(rolling_xor_decrypt(ciphertext, start, mod))[1:-1]
            print(f"[{hex(ciphertext_addr)}, xref: {hex(xor_block_ea)}]: {decrypted_str}")
            idc.set_cmt(ciphertext_addr, decrypted_str, 1)
        except:
            pass

    # Phase two: identify export resolving routine and add comments for API names
    api_resolver_indexer_address = None
    for api_resolver_indexer_offset in yara_scan(data, RULE_SOURCE_2):
        api_resolver_indexer_address = idaapi.get_fileregion_ea(api_resolver_indexer_offset)
        break
    
    # Walk the API resolver code until we find the pointer to the export and module sha1/salt arrays
    exports_array_address, modules_array_address = find_exports_and_modules_addresses(api_resolver_indexer_address)


    # Find cross references to the API resolver function, resolve APIs via index and set comments
    api_resolver_address = idc.get_func_attr(api_resolver_indexer_address, idc.FUNCATTR_START)
    for xref in idautils.XrefsTo(api_resolver_address, flags=0):
        resolve_api_set_comment(xref.frm, exports_array_address, modules_array_address)
    
    # Find the API resolver "wrapper" which simply is called with a single argument
    # for the index and calls the API resolver routine
    wrapper_address = find_api_resolver_wrapper(api_resolver_address)
    if wrapper_address:
        # Find cross references, set comments
        print(f"Identified API resolver wrapper at: {hex(wrapper_address)}")
        for xref in idautils.XrefsTo(wrapper_address, flags=0):
            resolve_api_set_comment(xref.frm, exports_array_address, modules_array_address)


    aes_table_ea, aes_routine_address = find_aes_encrypted_strings_and_routine()
    end = idc.next_head(aes_table_ea)
    size = end - aes_table_ea
    aes_table = idc.get_bytes(aes_table_ea, size)
    entries = parse_aes_table(aes_table)

    # Find cross references to the AES-128-CTR decrypt function
    # Resolve via offset (first arg) and comment string

    for xref in idautils.XrefsTo(aes_routine_address, flags=0):
        offset = infer_offset_from_call_site(xref.frm)
        if offset in entries:
            plaintext = entries[offset]["plaintext"]
            comment_str = repr(plaintext)[2:-1]
            idc.set_cmt(xref.frm, comment_str, 0)
            print(f"[{offset}, xref: {hex(xref.frm)}]: {comment_str}")



if __name__ == "__main__":
    main()