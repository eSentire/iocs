"""
Description: Decrypt strings in Amatera Stealer, resolve APIs, set comments/rename globals
Author: YungBinary
"""

import ida_hexrays
import ida_funcs
import idautils
import xtea
import os
import json


CAST_REF = (ida_hexrays.cot_cast, ida_hexrays.cot_ref)
DEREF = CAST_REF + (ida_hexrays.cot_ptr, ida_hexrays.cot_memref,
                    ida_hexrays.cot_memptr, ida_hexrays.cot_idx)

CURRENT_DIRECTORY = os.path.dirname(idc.get_input_file_path())


def xor_decrypt(src, key, maxlen=512):
    out = bytearray()
    for i in range(maxlen):
        b = ida_bytes.get_byte(src + i)
        if b == 0:
            return bytes(out)
        out.append((b ^ key) & 0xFF)





def find_xor_imm8_in_func(fn_ea):
    """ Yield every `xor <byte_reg>, imm8` instruction inside a given function."""
    fn = ida_funcs.get_func(fn_ea)
    if fn is None:
        return
    ea = fn.start_ea
    while ea < fn.end_ea:
        if idc.print_insn_mnem(ea) == 'xor':
            op0 = idc.print_operand(ea, 0).strip().lower()
            if idc.get_operand_type(ea, 1) == idc.o_imm:
                yield ea, op0, idc.get_operand_value(ea, 1) & 0xFF
        ea = idc.next_head(ea, fn.end_ea)


def find_xor_block_ciphertext_address(xor_ea, lookback=40):
    """From an `xor ??, imm8` walk backward to recover the source global."""

    ea = xor_ea
    xmm = None
    for _ in range(lookback):
        ea = idc.prev_head(ea)
        if ea == idc.BADADDR:
            return None
        if idc.print_insn_mnem(ea) in ['movq', 'movups']:
            op0 = idc.print_operand(ea, 0).strip().lower()
            op1 = idc.print_operand(ea, 1).strip().lower()
            if 'esp' in op0 and op1.startswith('xmm'):
                xmm = op1
                break
    if xmm is None:
        return None

    for _ in range(lookback):
        ea = idc.prev_head(ea)
        if ea == idc.BADADDR:
            return None
        if idc.print_insn_mnem(ea) in ['movq', 'movups']:
            op0 = idc.print_operand(ea, 0).strip().lower()
            if op0 == xmm and idc.get_operand_type(ea, 1) == idc.o_mem:
                return idc.get_operand_value(ea, 1)
    return None


def decrypt_xor_blocks():
    """ Find every XOR block in functions and decrypt them, set comments. """

    for fn_ea in idautils.Functions():
        for xor_ea, reg, key in find_xor_imm8_in_func(fn_ea):
            src_addr = find_xor_block_ciphertext_address(xor_ea)
            if not src_addr:
                print(f'Could not find ciphertext source address for XOR block: {hex(xor_ea)}')
                continue

            try:
                decrypted_str = xor_decrypt(src_addr, key).decode()
                print(f'XOR decrypt at {hex(xor_ea)} --> {decrypted_str}')
                idc.set_cmt(xor_ea, decrypted_str, 0)
            except:
                continue


def _peel(e, ops):
    while e.op in ops:
        e = e.x
    return e


def _var_idx(e):
    e = _peel(e, DEREF)
    return e.v.idx if e.op == ida_hexrays.cot_var else None


def _value(e):
    e = _peel(e, DEREF)
    if e.op == ida_hexrays.cot_obj:
        return ("ea", e.obj_ea)
    if e.op == ida_hexrays.cot_num:
        return ("imm", e.numval())
    if e.op == ida_hexrays.cot_call and len(e.a) == 1:
        inner = _peel(e.a[0].cexpr, DEREF)
        if inner.op == ida_hexrays.cot_obj:
            return ("ea", inner.obj_ea)
    return None


def _read_json(json_file):
    with open(json_file) as f:
        return json.load(f)


EXPORTS_LIST = _read_json(os.path.join(CURRENT_DIRECTORY, 'exports_map.json'))


def hash_to_export_name(export_hash: int, seed: int) -> str:
    for export_dict in EXPORTS_LIST:
        dll_name = export_dict['dll_name']
        for export_name in export_dict['exports']:
            computed_hash = dnjb2_hash(export_name, seed)
            if computed_hash == export_hash:
                return export_name


def find_api_hash(ea):
    """ Given a call-site to the API resolver, get the hash value"""

    cur = idc.prev_head(ea)  
    while cur != idaapi.BADADDR:
        if (idc.print_insn_mnem(cur) == 'mov' and idc.get_operand_type(cur, 1) == idc.o_imm):
            return idc.get_operand_value(cur, 1) & 0xFFFFFFFF
        elif (idc.print_insn_mnem(cur) == 'push' and idc.get_operand_type(cur, 0) == idc.o_imm):
            return idc.get_operand_value(cur, 0) & 0xFFFFFFFF
        cur = idc.prev_head(cur)


def capture_call_args(target_ea, n_args=2, debug=False):
    func = ida_funcs.get_func(target_ea)
    if not func:
        return None
    cfunc = ida_hexrays.decompile(func.start_ea)
    if not cfunc:
        return None

    lvars = cfunc.get_lvars()
    stkoff_to_idx = {lv.location.stkoff(): i for i, lv in enumerate(lvars)
                     if lv.location.is_stkoff()}
    last_value = {}  # idx -> (ea, value)
    elem_writes = {}  # idx -> {n: (ea, imm_value)}
    arg_keys = {}
    asg_log = []

    class V(ida_hexrays.ctree_visitor_t):
        def __init__(self):
            ida_hexrays.ctree_visitor_t.__init__(self, ida_hexrays.CV_FAST)

        def visit_expr(self, e):
            if e.op == ida_hexrays.cot_asg and e.ea < target_ea:
                lhs = e.x
                if (lhs.op == ida_hexrays.cot_idx
                        and lhs.x.op == ida_hexrays.cot_var
                        and lhs.y.op == ida_hexrays.cot_num):
                    v = _value(e.y)
                    if v is not None and v[0] == "imm":
                        n = lhs.y.numval()
                        prev = elem_writes.get(lhs.x.v.idx, {}).get(n)
                        if prev is None or prev[0] < e.ea:
                            elem_writes.setdefault(lhs.x.v.idx, {})[n] = (e.ea, v[1])
                        if debug:
                            asg_log.append((e.ea, lhs.x.v.idx, lhs.dstr(),
                                            e.y.opname, e.y.dstr(), v))
                        return 0
                idx, v = _var_idx(lhs), _value(e.y)
                if debug and idx is not None:
                    asg_log.append((e.ea, idx, lhs.dstr(),
                                    e.y.opname, e.y.dstr(), v))
                if idx is not None and v is not None:
                    prev = last_value.get(idx)
                    if prev is None or prev[0] < e.ea:
                        last_value[idx] = (e.ea, v)
                        if idx in elem_writes:
                            elem_writes.pop(idx, None)
            elif e.op == ida_hexrays.cot_call:
                if e.ea == target_ea:
                    for i, arg in enumerate(list(e.a)[:n_args]):
                        arg_keys[i] = _var_idx(arg.cexpr)
                elif e.ea < target_ea and len(e.a) == 3:
                    dst = _var_idx(e.a[0].cexpr)
                    src = _peel(e.a[1].cexpr, CAST_REF)
                    n = _peel(e.a[2].cexpr, CAST_REF)
                    if (dst is not None
                            and src.op == ida_hexrays.cot_obj
                            and n.op == ida_hexrays.cot_num):
                        prev = last_value.get(dst)
                        if prev is None or prev[0] < e.ea:
                            last_value[dst] = (e.ea, ("ea", src.obj_ea))
                            elem_writes.pop(dst, None)
            return 0

    V().apply_to(cfunc.body, None)

    if debug:
        arg_idx_set = set(arg_keys.values())
        for i in range(n_args):
            idx = arg_keys.get(i)
            lv = lvars[idx] if idx is not None else None
            lv_entry = last_value.get(idx)
            print("[arg%d] idx=%s name=%s last_value=%s elem_writes=%s"
                  % (i, idx, lv.name if lv else None,
                     lv_entry[1] if lv_entry else None,
                     elem_writes.get(idx)))
        print("[asg log for arg lvars]")
        for ea, idx, lhs, rhs_op, rhs_text, captured in asg_log:
            if idx in arg_idx_set:
                print("  ea=0x%x %s = %s (rhs_op=%s) -> captured=%s"
                      % (ea, lhs, rhs_text, rhs_op, captured))

    def resolve(i):
        idx = arg_keys.get(i)
        if idx is None:
            return None
        entry = last_value.get(idx)
        v = entry[1] if entry else None
        if v is not None:
            if v[0] != "imm" or not lvars[idx].location.is_stkoff():
                return v
            combined = v[1] & ((1 << (lvars[idx].width * 8)) - 1)
            total = lvars[idx].width
            cur = lvars[idx].location.stkoff() + total
            while total < 8:
                j = stkoff_to_idx.get(cur)
                nentry = last_value.get(j) if j is not None else None
                nv = nentry[1] if nentry else None
                if nv is None or nv[0] != "imm":
                    break
                w = lvars[j].width
                combined |= (nv[1] & ((1 << (w * 8)) - 1)) << (total * 8)
                total += w
                cur += w
            return ("imm", combined)
        elems = elem_writes.get(idx)
        if elems:
            combined = 0
            for n in range(max(elems) + 1):
                entry = elems.get(n)
                val = entry[1] if entry else 0
                combined |= (val & 0xFFFFFFFF) << (n * 32)
            return ("imm", combined)
        return None

    return {"arg%d" % i: resolve(i) for i in range(n_args)}


def find_string_length(ea):      
    """    
    Walk backward from `ea` to find the immediate-pushed length argument.
    Returns the value of the first `push imm` encountered.
    """                                    
    cur = idc.prev_head(ea)  
    while cur != idaapi.BADADDR:
        insn = ida_ua.insn_t()
        if ida_ua.decode_insn(insn, cur) == 0:
            break

        if (insn.get_canon_mnem() == 'push'
                and insn.ops[0].type == ida_ua.o_imm):
            return insn.ops[0].value

        cur = idc.prev_head(cur)

    return None


def _find_pattern(pattern, start, end):
    """Find a wildcard byte pattern. Compatible with IDA 7.x-9.x."""
    if hasattr(ida_bytes, "compiled_binpat_vec_t"):
        # IDA 9: ida_bytes.bin_search with a compiled pattern.
        binpat = ida_bytes.compiled_binpat_vec_t()
        ida_bytes.parse_binpat_str(binpat, start, pattern, 16)
        result = ida_bytes.bin_search(start, end, binpat, ida_bytes.BIN_SEARCH_FORWARD)
        if isinstance(result, tuple):
            return result[0]
        return result
    # IDA <= 8: ida_search.find_binary.
    import ida_search
    return ida_search.find_binary(start, end, pattern, 16, ida_search.SEARCH_DOWN)


def find_xtea_decrypt_buf():
    """
    Find xtea_decrypt_buf by signature; return the containing function's start ea.

    Wildcards cover the [esp+disp] stack-arg offsets, which can shift between
    samples depending on local-variable layout.
    """
    # 8B 74 24 ??   mov esi, [esp+arg]   ; offset varies
    # 8B 7C 24 ??   mov edi, [esp+arg]   ; offset varies
    # 8D 46 07      lea eax, [esi+7]     ; +7 from the round-up
    # 83 E0 F8      and eax, 0FFFFFFF8h  ; round up to multiple of 8
    pattern = "8B 74 24 ?? 8B 7C 24 ?? 8D 46 07 83 E0 F8"

    ea = _find_pattern(pattern, idaapi.inf_get_min_ea(), idaapi.inf_get_max_ea())
    if ea is None or ea == idaapi.BADADDR:
        return None

    func = ida_funcs.get_func(ea)
    return func.start_ea if func else None


def find_api_resolver_and_seed():
    pattern = "89 D7 C1 E7 05 01 D7 0F B6 D1 01 FA"
    ea = _find_pattern(pattern, idaapi.inf_get_min_ea(), idaapi.inf_get_max_ea())
    if ea is None or ea == idaapi.BADADDR:
        return None, None

    func = ida_funcs.get_func(ea)
    if not func:
        return None, None

    seed = None

    insn = idc.prev_head(ea)
    if idc.print_insn_mnem(insn) == "mov" and idc.get_operand_type(insn, 1) == idc.o_imm:
        seed = idc.get_operand_value(insn, 1) & 0xFFFFFFFF
    
    return func.start_ea, seed


def dnjb2_hash(string: str, seed: int) -> int:
    j = seed
    for c in string:
        j = (33 * j + (ord(c))) & 0xFFFFFFFF
    return j


def _stmt_ea_for(cfunc, ea):
    """Return the cinsn_t EA that wraps the given disassembly EA, or `ea` itself."""
    eamap = cfunc.get_eamap()
    for item in eamap.get(ea, []):
        if not item.is_expr():
            return item.ea
    return ea


def add_pseudo_cmt(cfunc, ea, comment):
    """Attach a pseudocode comment"""
    stmt_ea = _stmt_ea_for(cfunc, ea)
    tl = ida_hexrays.treeloc_t()
    tl.ea = stmt_ea
    tl.itp = ida_hexrays.ITP_SEMI
    cfunc.set_user_cmt(tl, comment)
    cfunc.refresh_func_ctext()


def main():

    # Decrypt XOR blocks
    decrypt_xor_blocks()


    # Find the xtea decrypt routine
    decrypt_xtea_ea = find_xtea_decrypt_buf()
    if decrypt_xtea_ea:
        # Find all cross references to xtea decrypt function
        for xref_to_xtea in idautils.XrefsTo(decrypt_xtea_ea):
            # Get the final string length from the proxy function
            string_length = find_string_length(xref_to_xtea.frm)
            # Get the address of the function calling the xtea decrypt function
            # Walk up to find the arguments, ecx contains ciphertext, edx contains key
            proxy_ea = idc.get_func_attr(xref_to_xtea.frm, idc.FUNCATTR_START)
            for xref_to_proxy in idautils.XrefsTo(proxy_ea):
                call_site_ea = xref_to_proxy.frm
                # ecx (arg0) is ciphertext
                # edx (arg1) is key
                args = capture_call_args(call_site_ea)
                arg0 = args['arg0']
                arg1 = args['arg1']
                key = ida_bytes.get_bytes(arg1[1], 16)
                read_size = (string_length + 7) & 0xFFFFFFF8

                ciphertext = b''
                if 'imm' in arg0:
                    ciphertext = arg0[1].to_bytes(read_size, 'little')
                else:
                    ciphertext = ida_bytes.get_bytes(arg0[1], read_size)

                x = xtea.new(key, mode=xtea.MODE_ECB, endian="<")
                decrypted_string = x.decrypt(ciphertext)[:string_length]
                #print(f"XTEA proxy call site: {hex(call_site_ea)}, Ciphertext: {hex(arg0[1])}, XTEA Key: {key.hex()}, String length: {string_length}")
                try:
                    print(f"XTEA proxy call site: {hex(call_site_ea)}, plaintext: {decrypted_string.decode()}")
                    idc.set_cmt(call_site_ea, decrypted_string.decode(), 0)
                    ea = idc.get_func_attr(call_site_ea, idc.FUNCATTR_START)
                    cfunc = ida_hexrays.decompile(ea)
                    add_pseudo_cmt(cfunc, call_site_ea, decrypted_string.decode())
                except Exception as e:
                    print(e)
                    continue

    # Find the API resolver function and seed
    api_resolver_ea, dnjb2_seed = find_api_resolver_and_seed()
    if api_resolver_ea and dnjb2_seed:
        # Find all cross references to API resolver function
        for xref_to_api_resolver in idautils.XrefsTo(api_resolver_ea):
            export_hash = find_api_hash(xref_to_api_resolver.frm)
            if not export_hash:
                print(f'Failed resolving export hash at API resolver call-site: {hex(xref_to_api_resolver.frm)}')
                continue
            # Lookup the API hash in exports map
            export_name = hash_to_export_name(export_hash, dnjb2_seed)
            if export_name:
                print(f'API resolver call-site: {hex(xref_to_api_resolver.frm)}, hash: {hex(export_hash)} --> {export_name}')
                idc.set_cmt(xref_to_api_resolver.frm, export_name, 0)
                ea = idc.get_func_attr(xref_to_api_resolver.frm, idc.FUNCATTR_START)
                cfunc = ida_hexrays.decompile(ea)
                add_pseudo_cmt(cfunc, xref_to_api_resolver.frm, export_name)
            else:
                print(f"API resolver call-site: {hex(xref_to_api_resolver.frm)}, failed resolving API hash: {hex(export_hash)}")



if __name__ == "__main__":

    if not ida_hexrays.init_hexrays_plugin():
        raise RuntimeError("Hex-Rays decompiler not available...")

    main()
